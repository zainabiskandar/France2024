## Goal

Remove the About page entirely and place the provided introductory text below the gallery on the Home page.

## Changes

**1. Remove About page**
- Delete `src/pages/About.tsx`
- Delete `src/components/about/AboutPageLayout.tsx` (and `src/components/about/` if empty)
- Remove the `/about` route + lazy import from `src/App.tsx`
- Remove the "About" link from `src/components/layout/HeaderNavigation.tsx` (both desktop and mobile menus)

**2. Add intro text below the gallery on Home**
- Create `src/components/home/HomeIntro.tsx` — renders:
  - Blockquote: *"On ne voit bien qu'avec le cœur. L'essentiel est invisible pour les yeux."* — Antoine de Saint-Exupéry, *The Little Prince* (French in italic serif, attribution in smaller muted text)
  - Lead line: "This is an archive of my Language Immersion Programme in France (2024)."
  - Paragraph: the Paris/Besançon/CLA description
- Render it in `src/pages/Home.tsx` directly under `<FilmstripGallery />`
- Use semantic design tokens (`text-foreground`, `text-muted-foreground`, existing serif font classes) — no hardcoded colors

**3. Layout adjustment**
- The home `Layout` currently locks to viewport height (`md:h-screen md:overflow-hidden`) and vertically centers the gallery. Adding text below breaks that model.
- Switch the Home variant to use the scrollable `fullPage` layout (or relax the height lock) so the gallery sits at the top of the viewport with the intro text scrolling beneath it on desktop, and stacks naturally on mobile.
- Keep the gallery's existing expand-on-hover behavior and dimensions intact (per memory).

**4. SEO**
- Update Home `<SEO>` description to use the new tagline/intro context.
- Remove any About-related sitemap entry in `public/sitemap.xml` if present.

## Out of scope

- Gallery interaction changes
- Header restructure beyond removing the About link
- Editing `public/data/photographer.json` (biography fields become unused but harmless; can prune later if desired)

## Open question

The current Home layout centers the gallery in the viewport with no scroll on desktop. To fit the intro text below, I'll switch Home to a scrollable layout (gallery sits near the top, text follows below the fold on smaller screens / inline on tall screens). Let me know if you'd prefer instead to shrink the gallery so both fit within one viewport without scrolling.