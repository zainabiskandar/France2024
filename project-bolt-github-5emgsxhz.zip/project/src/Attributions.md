This project includes components from [shadcn/ui](https://ui.shadcn.com/) used under [MIT license](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

Photos are from [Unsplash](https://unsplash.com) used under [license](https://unsplash.com/license).